--- STEAMODDED HEADER
--- MOD_NAME: Fem Jokers
--- MOD_ID: FemJokers
--- MOD_AUTHOR: [DanganMachin & toneblock]
--- MOD_DESCRIPTION: Every Joker by Matttttt99. Constellation by DrSmey.

----------------------------------------------
------------MOD CODE -------------------------

function SMODS.INIT.FemJokers()
    sendDebugMessage("Launching Fem Jokers!")

    local negate_mod = SMODS.findModByID("FemJokers")
    local sprite_jkr = SMODS.Sprite:new("Joker", negate_mod.path, "custom-jokers.png", 71, 95, "asset_atli")

    sprite_jkr:register()
end

----------------------------------------------
------------MOD CODE END----------------------